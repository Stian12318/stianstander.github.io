import React from 'react'

function Pricing() {
    return (
        <div><h1>Pricing</h1></div>
    )
}

export default Pricing